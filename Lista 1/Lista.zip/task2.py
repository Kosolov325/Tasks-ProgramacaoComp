salB = float(input("Escreva seu salário: "))
reaJ = float(input("Escreva o valor do reajuste: "))
salL = salB * (1 + reaJ/100)
print(salL)