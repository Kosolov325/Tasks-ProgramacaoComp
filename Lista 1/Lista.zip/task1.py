val = int(input("Escreva um valor inteiro: "))
print (val-1)
