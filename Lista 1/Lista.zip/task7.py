nome = "Lúcia Cavalcante"
print(nome[6:-7])